import React from 'react'
import "./PostFooterStyle.css"

export const PostFooter = () => {
  return (
    <div className='postFooter'>
        <div className="footerFinal">
            <p className="text-center">©OKUS-PAY | Buenos Aires - Argentina </p>
        </div>
    </div>
  )
}
